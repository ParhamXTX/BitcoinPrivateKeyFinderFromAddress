﻿long i = 0;
bool shouldGenerate = true;
System.Timers.Timer aTimer;
String addressesList;
Console.WriteLine("Enter Addresses To Find Private Keys of them : ");
addressesList = Console.ReadLine();
if (addressesList != null)
{
    if (addressesList != String.Empty)
    {
        if (addressesList != "")
        {
            {
                if (addressesList.Length > 0)
                {
                    Console.WriteLine("Process Started!!! ");
                    SetTimer();
                    for (int t = 0; t < System.Environment.ProcessorCount; i++)
                    {
                        Thread thread = new Thread(new ThreadStart(Generate));
                    }
                    
                }
            }
        }
    }
}
void SetTimer()
{
    // Create a timer with a two second interval.
    aTimer = new System.Timers.Timer(10000);
    // Hook up the Elapsed event for the timer. 
    aTimer.Elapsed += OnTimedEvent;
    aTimer.AutoReset = true;
    aTimer.Enabled = true;
}
void OnTimedEvent(Object source, System.Timers.ElapsedEventArgs e)
{
    Console.WriteLine("Time : {0:HH:mm:ss.fff}",
                      e.SignalTime+"     Number of Generations : "+i);
}
void Generate()
{
    if (shouldGenerate == true)
    {
        for (i = 0; i < long.MaxValue; i++)
        {
            NBitcoin.Key key = new NBitcoin.Key();
            NBitcoin.BitcoinSecret bitcoinSecret = new NBitcoin.BitcoinSecret(key, NBitcoin.Network.Main);
            var addrlegacy = bitcoinSecret.GetAddress(NBitcoin.ScriptPubKeyType.Legacy);
            var addrsegwit = bitcoinSecret.GetAddress(NBitcoin.ScriptPubKeyType.Segwit);
            var addrsegwitp2sh = bitcoinSecret.GetAddress(NBitcoin.ScriptPubKeyType.SegwitP2SH);
            var addrtaprootBIP86 = bitcoinSecret.GetAddress(NBitcoin.ScriptPubKeyType.TaprootBIP86);

            if (addressesList.Contains(addrlegacy.ToString()) || addressesList.Contains(addrsegwit.ToString()) || addressesList.Contains(addrsegwitp2sh.ToString()) || addressesList.Contains(addrtaprootBIP86.ToString()))
            {
                Console.WriteLine("Found One Of The Addresses Corresponding Private Key : " + key);
                shouldGenerate = false;
            }

            long max = (long.MaxValue - 1);
            if (i == max)
            {
                i = 0;
            }
        }
    }
}
